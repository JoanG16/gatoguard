-- Mapea cada gateway a un nombre de zona legible.
-- Ajusta los valores según cómo llamaste deviceID en cada M5Stack.
CREATE TABLE IF NOT EXISTS zonas (
    device_id   TEXT PRIMARY KEY,
    nombre_zona TEXT NOT NULL
);

INSERT INTO zonas (device_id, nombre_zona) VALUES
    ('M5_PISO_1_ESCRITORIO', 'Escritorio'),
    ('M5_PISO_1_COCINA', 'Cocina')
ON CONFLICT (device_id) DO UPDATE SET nombre_zona = EXCLUDED.nombre_zona;

-- Guarda la última zona decidida por el algoritmo (una fila, se actualiza siempre).
CREATE TABLE IF NOT EXISTS estado_actual (
    mac             TEXT PRIMARY KEY,
    device_id       TEXT NOT NULL,
    nombre_zona     TEXT NOT NULL,
    rssi_promedio   NUMERIC(6,2) NOT NULL,
    actualizado_en  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Historial de cambios de zona (para revisar después qué tan seguido "saltó").
CREATE TABLE IF NOT EXISTS historial_zona (
    id              BIGSERIAL PRIMARY KEY,
    mac             TEXT NOT NULL,
    device_id       TEXT NOT NULL,
    nombre_zona     TEXT NOT NULL,
    rssi_promedio   NUMERIC(6,2) NOT NULL,
    cambiado_en     TIMESTAMPTZ NOT NULL DEFAULT now()
);
