require('dotenv').config();
const { Pool } = require('pg');

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// --- CONFIGURACIÓN ---
const TARGET_MAC = process.env.TARGET_MAC || 'dd:88:00:00:3e:15';
const WINDOW_SECONDS = 6;      // ventana de lecturas recientes a promediar (suavizado)
const HYSTERESIS_MARGIN = 4;   // dB que la nueva zona debe superar a la actual para cambiar
const POLL_INTERVAL_MS = 3000; // cada cuánto se re-evalúa

let currentZoneDeviceId = null; // estado en memoria para aplicar histéresis

async function evaluarZona() {
  // Promedio de RSSI por device_id en la ventana reciente, solo para el beacon objetivo.
  const { rows } = await pool.query(
    `SELECT device_id, AVG(rssi)::numeric(6,2) AS rssi_promedio, COUNT(*) AS muestras
     FROM telemetria_raw
     WHERE mac = $1 AND time > now() - ($2 || ' seconds')::interval
     GROUP BY device_id`,
    [TARGET_MAC, WINDOW_SECONDS]
  );

  if (rows.length === 0) {
    console.log(`[${new Date().toISOString()}] Sin lecturas recientes del beacon ${TARGET_MAC}.`);
    return;
  }

  // Candidato: el device_id con mejor (mayor) RSSI promedio.
  rows.sort((a, b) => b.rssi_promedio - a.rssi_promedio);
  const candidato = rows[0];

  console.log(
    `[${new Date().toISOString()}] Lecturas: ` +
    rows.map(r => `${r.device_id}=${r.rssi_promedio}dBm(${r.muestras})`).join(', ')
  );

  let zonaFinal = candidato;

  if (currentZoneDeviceId && currentZoneDeviceId !== candidato.device_id) {
    // Hay una zona previa distinta al candidato: aplicar histéresis.
    const actual = rows.find(r => r.device_id === currentZoneDeviceId);
    const rssiActual = actual ? Number(actual.rssi_promedio) : -999;
    const diferencia = Number(candidato.rssi_promedio) - rssiActual;

    if (diferencia < HYSTERESIS_MARGIN) {
      // No supera el margen: nos quedamos en la zona actual para evitar parpadeo.
      zonaFinal = actual || candidato;
      console.log(
        `  -> Candidato "${candidato.device_id}" no supera el margen de histéresis ` +
        `(+${diferencia.toFixed(1)}dB < ${HYSTERESIS_MARGIN}dB). Se mantiene zona actual.`
      );
    }
  }

  const cambioDeZona = zonaFinal.device_id !== currentZoneDeviceId;
  currentZoneDeviceId = zonaFinal.device_id;

  // Nombre de zona legible desde la tabla `zonas`
  const { rows: zonaRows } = await pool.query(
    `SELECT nombre_zona FROM zonas WHERE device_id = $1`,
    [zonaFinal.device_id]
  );
  const nombreZona = zonaRows[0]?.nombre_zona || zonaFinal.device_id;

  await pool.query(
    `INSERT INTO estado_actual (mac, device_id, nombre_zona, rssi_promedio, actualizado_en)
     VALUES ($1, $2, $3, $4, now())
     ON CONFLICT (mac) DO UPDATE
       SET device_id = EXCLUDED.device_id,
           nombre_zona = EXCLUDED.nombre_zona,
           rssi_promedio = EXCLUDED.rssi_promedio,
           actualizado_en = now()`,
    [TARGET_MAC, zonaFinal.device_id, nombreZona, zonaFinal.rssi_promedio]
  );

  if (cambioDeZona) {
    console.log(`  >>> CAMBIO DE ZONA: ahora en "${nombreZona}" (${zonaFinal.rssi_promedio}dBm)`);
    await pool.query(
      `INSERT INTO historial_zona (mac, device_id, nombre_zona, rssi_promedio)
       VALUES ($1, $2, $3, $4)`,
      [TARGET_MAC, zonaFinal.device_id, nombreZona, zonaFinal.rssi_promedio]
    );
  }
}

console.log(`Iniciando detector de zona para beacon ${TARGET_MAC}...`);
console.log(`Ventana: ${WINDOW_SECONDS}s | Histéresis: ${HYSTERESIS_MARGIN}dB | Poll: ${POLL_INTERVAL_MS}ms\n`);

setInterval(() => {
  evaluarZona().catch(err => console.error('[ERROR] evaluarZona:', err.message));
}, POLL_INTERVAL_MS);

process.on('SIGINT', async () => {
  console.log('\nCerrando...');
  await pool.end();
  process.exit(0);
});
